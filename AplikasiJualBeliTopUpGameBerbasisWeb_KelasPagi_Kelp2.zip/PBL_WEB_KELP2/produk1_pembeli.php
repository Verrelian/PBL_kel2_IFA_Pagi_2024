<?php

// Nama File : produk1_pembeli.php
// Deskripsi : Kode ini merupakan kode yang menampilkan menu produk pubg yang ada di website kami di sisi pembeli
// Dibuat Oleh : Neli Fauziyah - 3312401007 Disempurnakan oleh Wahyudi - 3312401014
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

try {
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['type_user'])) {
        // Pengguna belum login, arahkan ke halaman login
        header("Location: login.php");
        exit();
    }

    // Cek apakah tipe user yang login adalah 'pembeli'
    if ($_SESSION['type_user'] !== 'pembeli') {
        header("Location: dashboard_penjual.php"); // Dashboard penjual
        exit();
    }

    // Pastikan koneksi berhasil
    if (!file_exists("koneksi.php")) {
        throw new Exception("File koneksi tidak ditemukan.");
    }

    include("koneksi.php");

    if (!$koneksi) {
        throw new Exception("Koneksi ke database gagal.");
    }

    if (isset($_POST['Confirm'])) {
        if (isset($_POST['user_id'])) {
            $user_id = mysqli_real_escape_string($koneksi, $_POST['user_id']);
            $sql = "SELECT * FROM pembeli WHERE user_id = '$user_id'";
            $result = $koneksi->query($sql);

            if (!$result) {
                throw new Exception("Query untuk validasi user ID gagal: " . mysqli_error($koneksi));
            }

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $username = $row['username'];
                $email = $row['email'];
            } else {
                echo "<script>alert('User ID tidak ditemukan.');
                        window.location = 'produk1_pembeli.php';
                      </script>";
                exit();
            }
        }

        // Validasi data produk dan pembayaran
        if (!isset($_POST['product']) || !isset($_POST['payment_method'])) {
            throw new Exception("Data produk atau metode pembayaran tidak lengkap.");
        }

        $product_data = mysqli_real_escape_string($koneksi, $_POST['product']);
        $metode_pembayaran = mysqli_real_escape_string($koneksi, $_POST['payment_method']);

        if (!strpos($product_data, '|')) {
            throw new Exception("Format data produk tidak valid.");
        }

        list($nama_produk, $harga_produk) = explode('|', $product_data);

        $cek_stok = "SELECT stok FROM pubg WHERE nama_produk = '$nama_produk'";
        $stok_result = mysqli_query($koneksi, $cek_stok);

        if (!$stok_result) {
            throw new Exception("Query untuk cek stok gagal: " . mysqli_error($koneksi));
        }

        $stok_data = mysqli_fetch_assoc($stok_result);

        if ($stok_data) {
            $stok_tersedia = $stok_data['stok'];

            if ($stok_tersedia > 0) {
                $sql = "INSERT INTO transaksi (user_id, nama_produk, harga_produk, metode_pembayaran)
                        VALUES ('$user_id', '$nama_produk', '$harga_produk', '$metode_pembayaran')";

                if (!mysqli_query($koneksi, $sql)) {
                    throw new Exception("Gagal menyimpan data transaksi: " . mysqli_error($koneksi));
                }

                $id_transaksi = mysqli_insert_id($koneksi);

                $update_stok = "UPDATE pubg SET stok = stok - 1 WHERE nama_produk = '$nama_produk'";

                if (!mysqli_query($koneksi, $update_stok)) {
                    throw new Exception("Gagal mengurangi stok produk: " . mysqli_error($koneksi));
                }

                echo "<script>
                        alert('Pesanan berhasil disimpan!');
                        window.location = 'payment_receipt1.php?id_transaksi=" . $id_transaksi . "';
                      </script>";
            } else {
                echo "<script>alert('Stok produk tidak cukup untuk pemesanan ini.');</script>";
            }
        } else {
            echo "<script>alert('Produk tidak ditemukan.');</script>";
        }
    }
} catch (Exception $e) {
    echo "<script>alert('Terjadi kesalahan: " . $e->getMessage() . "');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PUBG Top Up</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link href="stylep.css" rel="stylesheet">

</head>

<body>
    <!-- Header Section -->
    <header class="header">
        <button class="header-menu-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
            aria-controls="offcanvasMenu">
            ☰
        </button>
        <div class="header-left">
            <div class="header-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
        </div>
    </header>

    <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu"
        aria-labelledby="offcanvasMenuLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasMenuLabel"><img src="btc.png" class="logo"></h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link text-white active">
                        <i class="fas fa-home"></i> HOME
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list_of_games.php" class="nav-link text-white">
                        <i class="fas fa-gamepad"></i> LIST OF GAMES
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link text-white">
                        <i class="fas fa-user"></i> ACCOUNT
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Header Image -->
    <div class="position-relative">
        <img src="pubg_banner.jpg" alt="PUBG Characters Banner" class="header-image">
    </div>

    <!-- Main Content Container -->
    <div class="container position-relative">
        <!-- Game Logo and Title -->
        <div class="d-flex align-items-end mb-4">
            <img src="pubg.jpg" alt="PUBG Logo" class="game-logo">
            <div class="text-white ms-3 mb-4">
                <h1 class="fs-2 fw-bold mb-0">PUBG</h1>
                <p class="fs-5 mb-2">TENCENT GAMES</p>
            </div>
        </div>

        <!-- Main Content Card -->
        <div class="main-content text-white p-4 mb-4">
            <div class="row">
                <!-- Left Side Grid Container -->
                <div class="col-md-3">
                    <div class="left-side-grid">
                        <h2 class="fw-bold fs-5 mb-2">Reminder</h2>
                        <ol class="fs-5 mb-2">
                            <li>Make sure the ID you entered is correct.</li>
                            <li>Then select the product you want to purchase.</li>
                            <li>Ensure it matches your preferences.</li>
                            <li>Confirm your purchase.</li>
                        </ol>
                    </div>
                </div>

                <!-- Right Side Vertical Grid Container -->
                <div class="col-md-9">
                    <div class="main-grid">
                        <!-- Account Input Section -->
                        <div class="grid-item">
                            <h3 class="fw-bold fs-5 mb-3">Enter Your Account Data</h3>
                            <input type="text" class="form-control user-id-input" placeholder="User ID">
                            <small class="text-white-help">Please enter your account User ID correctly.</small>
                        </div>

                        <!-- Product Selection Section -->
                        <div class="grid-item">
                            <h3 class="fw-bold fs-5 mb-3">Choose Product</h3>
                            <div class="products-grid">
                                <?php
                                try {
                                    include 'koneksi.php'; // Koneksi ke database
                                    if (!$koneksi) {
                                        throw new Exception("Koneksi ke database gagal.");
                                    }

                                    // Query untuk mengambil data produk
                                    $query = mysqli_query($koneksi, "SELECT * FROM pubg");
                                    if (!$query) {
                                        throw new Exception("Gagal mengambil data produk: " . mysqli_error($koneksi));
                                    }

                                    while ($data = mysqli_fetch_assoc($query)) {
                                        $gambar = $data['gambar']; // Ambil path gambar dari database
                                        $stok = $data['stok']; // Ambil stok produk dari database
                                ?>
                                        <div class="product-card p-3 rounded">
                                            <i class="fas fa-check product-check"></i>

                                            <div class="fw-bold"><?php echo $data['nama_produk']; ?></div>
                                            <div class="text-white-help">
                                                <?php echo "Rp " . number_format($data['harga_produk'], 0, ',', '.'); ?>
                                            </div>

                                            <!-- Cek apakah stok = 0 dan tambahkan overlay -->
                                            <?php if ($stok == 0): ?>
                                                <!-- Produk habis, tampilkan overlay -->
                                                <div class="out-of-stock-overlay">Stok Habis</div>
                                                <img src="<?php echo $data['gambar']; ?>" alt="error" class="out-of-stock-img">
                                            <?php else: ?>
                                                <!-- Produk tersedia, tampilkan gambar biasa -->
                                                <img src="<?php echo $data['gambar']; ?>" alt="error">
                                            <?php endif; ?>
                                        </div>
                                    <?php } ?>
                            </div>
                        </div>

                        <div class="grid-item">
                            <h3 class="fw-bold fs-5 mb-3">Payment Methods</h3>
                            <div class="products-grid">
                                <?php
                                    include 'koneksi.php'; // Koneksi ke database
                                    if (!$koneksi) {
                                        throw new Exception("Koneksi ke database gagal.");
                                    }

                                    // Query untuk mengambil data metode pembayaran
                                    $query = mysqli_query($koneksi, "SELECT * FROM pembayaran");
                                    if (!$query) {
                                        throw new Exception("Gagal mengambil data metode pembayaran: " . mysqli_error($koneksi));
                                    }

                                    while ($data = mysqli_fetch_assoc($query)) {
                                ?>
                                    <div class="payment-card">
                                        <!-- Logo -->
                                        <img src="<?php echo $data['gambar']; ?>" alt="Payment Method Logo">
                                        <!-- Text -->
                                        <div class="payment-text"><?php echo $data['nama']; ?></div>
                                    </div>
                                <?php } ?>
                            <?php
                                } catch (Exception $e) {
                                    echo "<script>alert('Terjadi kesalahan: " . $e->getMessage() . "');</script>";
                                }
                            ?>
                            </div>
                        </div>
                    </div>

                    <!-- Confirmation Section -->
                    <div>
                        <button class="confirm-button">Top Up Confirmation</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content card shadow-lg">
                <div class="modal-header border-0" style="background-color: #283593; color: white;">
                    <h3 class="modal-title fw-bold" id="orderModalLabel">Order Details</h3>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card p-4 shadow-sm">
                        <p class="card-text fs-5">Please verify the order details. If everything is correct,
                            click Confirm to proceed.</p>
                        <ul class="list-unstyled">
                            <li class="mb-3">
                                <strong>USER ID</strong><br>
                                <span id="modal-user-id" class="text-muted">#12345</span><br>
                                <strong>ITEM TYPE</strong><br>
                                <span id="modal-product" class="text-muted">Product Name</span><br>
                                <strong>PRICE</strong><br>
                                <span id="modal-price" class="text-success fs-4">$99.99</span><br>
                                <strong>PAYMENT METHOD</strong><br>
                                <span id="modal-payment-method" class="text-muted">Credit Card</span>
                            </li>
                        </ul>
                        <div class="d-flex justify-content-between align-items-center">
                            <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-confirm" name="Confirm">Confirm</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
            <div class="footer-text">
                <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store!.</p>
            </div>
        </div>
        <p>© 2025 BTC Top Up Game Store. All Rights Reserved.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="jsp.js"></script>

</body>

</html>