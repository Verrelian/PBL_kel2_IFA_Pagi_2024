<?php
// Nama File : login.php 
// Deskripsi : Kode ini merupakan kode yang mengatur form forgot password
// Dibuat Oleh : Firli Hanifurahman - 3312401005 disempurnakan oleh Wahyudi - 3312401014
// Tanggal Pembuatan : 08-november-2024

session_start(); // Mulai sesi

// Include file koneksi untuk menghubungkan dengan database
include 'koneksi.php';

try {
    // Mengecek jika form login dikirim (dengan mengecek apakah tombol 'login' di-submit)
    if (isset($_POST['login'])) {
        // Mengambil input form dan melakukan sanitasi agar aman
        $username = mysqli_real_escape_string($koneksi, $_POST['username']);
        $password = mysqli_real_escape_string($koneksi, $_POST['password']);
        $type_user = mysqli_real_escape_string($koneksi, $_POST['type_user']);

        // Inisialisasi variabel tabel yang akan dipilih berdasarkan tipe user
        $table = '';
        if ($type_user == 'penjual') {
            $table = 'penjual'; // Jika tipe user 'penjual', maka menggunakan tabel 'penjual'
        } elseif ($type_user == 'pembeli') {
            $table = 'pembeli'; // Jika tipe user 'pembeli', maka menggunakan tabel 'pembeli'
        } else {
            // Jika tipe user tidak valid, set pesan error
            $error = "Tipe User tidak valid!";
        }

        // Jika tidak ada error sebelumnya, lakukan pengecekan ke database
        if (!isset($error)) {
            // Menyiapkan query untuk memeriksa apakah username sudah ada dalam database
            $query = "SELECT * FROM $table WHERE username='$username'";
            $result = mysqli_query($koneksi, $query);

            // Mengecek apakah username ditemukan
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result); // Ambil data pengguna

                // Verifikasi password yang diinputkan dengan yang ada di database
                if (password_verify($password, $row['password'])) {
                    // Jika login berhasil, mulai sesi dan set session untuk menyimpan data pengguna
                    $_SESSION['username'] = $username;
                    $_SESSION['type_user'] = $type_user;
                    $_SESSION['user_id'] = $row['user_id'];  // Menyimpan user_id dalam session

                    // Jika pengguna memilih opsi 'Remember me', buat cookie untuk menyimpan data login
                    if (isset($_POST['remember'])) {
                        setcookie('username', $username, time() + (86400 * 30), "/"); // Cookie untuk username, berlaku selama 30 hari
                        setcookie('type_user', $type_user, time() + (86400 * 30), "/"); // Cookie untuk tipe user, berlaku selama 30 hari
                    }

                    // Arahkan pengguna ke dashboard sesuai tipe user
                    if ($type_user == 'penjual') {
                        header("Location: dashboard_penjual.php"); // Penjual diarahkan ke dashboard penjual
                    } else {
                        header("Location: dashboard.php"); // Pembeli diarahkan ke dashboard pembeli
                    }
                    exit(); // Pastikan tidak ada kode lain yang dijalankan setelah redirect
                } else {
                    // Jika password salah, set pesan error
                    $error = "Password salah!";
                }
            } else {
                // Jika username tidak ditemukan di database, set pesan error
                $error = "Username tidak ditemukan!";
            }
        }
    }
} catch (Exception $e) {
    // Menangani exception dan menampilkan pesan error
    echo "Terjadi kesalahan: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="stylel.css" rel="stylesheet"> <!-- Menyertakan file CSS untuk gaya tampilan -->
</head>
<body>
    <div class="container">
        <div class="login-box">
            <h2>Log In</h2>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; // Menampilkan pesan error jika ada ?>
            <form method="POST" action="">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required value="<?php echo isset($_COOKIE['username']) ? $_COOKIE['username'] : ''; ?>">
                <!-- Jika username disimpan dalam cookie, tampilkan sebagai default value -->

                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>

                <label for="type_user">User Type</label>
                <select name="type_user" id="type_user" required>
                    <option value="penjual" <?php if(isset($_COOKIE['type_user']) && $_COOKIE['type_user'] == 'penjual') echo 'selected'; ?>>Penjual</option>
                    <option value="pembeli" <?php if(isset($_COOKIE['type_user']) && $_COOKIE['type_user'] == 'pembeli') echo 'selected'; ?>>Pembeli</option>
                </select>

                <label>
                    <input type="checkbox" name="remember" <?php if(isset($_COOKIE['username'])) echo 'checked'; ?>> Remember me
                </label>

                <button type="submit" name="login">Log In</button>
            </form>
            <div class="link">
                <p><a href="forgot_password.php">Forgot Password?</a></p> <!-- Link untuk lupa password -->
                <p>Don’t have an account? <a href="signup.php">Sign Up</a></p> <!-- Link ke halaman daftar -->
            </div>
        </div>
    </div>
</body>
</html>
