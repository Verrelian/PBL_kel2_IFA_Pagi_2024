<?php
// Nama File : edit.php
// Deskripsi : Kode ini merupakan kode yang mengatur form edit profil di sisi pembeli
// Dibuat Oleh : Firli Haniffurahman 3312401029 disempurnakan oleh Wahyudi - 3312401014
// Tanggal Pembuatan : 09-desember-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'pembeli'
// Jika bukan pembeli, arahkan ke halaman dashboard penjual
if ($_SESSION['type_user'] !== 'pembeli') {
    header("Location: dashboard_penjual.php"); // Dashboard penjual
    exit();
}

include 'koneksi.php'; // Menyertakan file koneksi

// Pastikan koneksi tersedia
if (!isset($koneksi)) {
    die("Koneksi database tidak tersedia.");
}

// Mengambil 'user_id' dari URL dan mengecek jika 'user_id' ada
$user_id = $_GET['user_id'] ?? null; // Jika tidak ada, akan menjadi null
if (!$user_id) {
    echo "ID pengguna tidak ditemukan!";
    exit(); // Hentikan eksekusi jika tidak ada ID
}

try {
    // Mendapatkan data pengguna berdasarkan 'user_id'
    $query = "SELECT * FROM pembeli WHERE user_id = '$user_id'";
    $result = mysqli_query($koneksi, $query);

    if (!$result || mysqli_num_rows($result) == 0) {
        throw new Exception("Pengguna tidak ditemukan!");
    }

    $data = mysqli_fetch_assoc($result); // Mengambil data pengguna

    // Memeriksa apakah form sudah disubmit
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Ambil data yang dikirimkan melalui POST
        $email = $_POST['email'] ?? '';
        $username = $_POST['username'] ?? '';

        // Validasi input
        if (empty($email) || empty($username)) {
            $error = "Email dan Username harus diisi!";
        } else {
            // Cek apakah email sudah terdaftar untuk pengguna lain
            $query_email_check = "SELECT * FROM pembeli WHERE email = '$email' AND user_id != '$user_id'";
            $result_email_check = mysqli_query($koneksi, $query_email_check);
            if (mysqli_num_rows($result_email_check) > 0) {
                $error = "Email sudah terdaftar!";
            }

            // Cek apakah username sudah terdaftar untuk pengguna lain
            $query_username_check = "SELECT * FROM pembeli WHERE username = '$username' AND user_id != '$user_id'";
            $result_username_check = mysqli_query($koneksi, $query_username_check);
            if (mysqli_num_rows($result_username_check) > 0) {
                $error = "Username sudah terdaftar!";
            }
        }

        // Jika tidak ada error, lakukan update
        if (!isset($error)) {
            $query_update = "UPDATE pembeli SET email = '$email', username = '$username' WHERE user_id = '$user_id'";
            $result_update = mysqli_query($koneksi, $query_update);

            // Jika update berhasil
            if ($result_update) {
                // Update session setelah perubahan berhasil
                $_SESSION['username'] = $username; // update username setelah edit
                $_SESSION['user_id'] = $user_id;   // update user_id setelah edit

                // Redirect ke halaman profil dengan sukses
                echo "<script>alert('Profil berhasil diperbarui!'); window.location.href = 'profile.php';</script>";
            } else {
                throw new Exception("Terjadi kesalahan, coba lagi!");
            }
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil</title>
    <link href="stylee.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">


</head>
<body>
    <div class="container">
        <div class="title">
            Edit Profil
        </div>

                        <?php if (isset($error)) { ?>
                    <!-- Menampilkan pesan error jika variabel $error terisi -->
                    <div class="alert"><?php echo $error; ?></div>
                <?php } ?>

                <form action="edit.php?user_id=<?php echo $user_id; ?>" method="POST">
                    <!-- Formulir untuk mengedit data, dikirimkan ke 'edit.php' menggunakan metode POST -->
                    <input type="hidden" name="user_id" value="<?php echo $data['user_id'] ?? ''; ?>">
                    <!-- Input tersembunyi untuk menyimpan 'user_id' yang diperlukan untuk pengidentifikasi data di server -->

                    <div class="form-group">
                        <label for="username">Username:</label>
                        <!-- Input teks untuk mengisi atau mengedit username -->
                        <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($data['username'] ?? ''); ?>" required>
                        <!-- 'htmlspecialchars' digunakan untuk mencegah serangan XSS -->
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <!-- Input email untuk mengisi atau mengedit alamat email -->
                        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($data['email'] ?? ''); ?>" required>
                        <!-- 'htmlspecialchars' digunakan untuk keamanan -->
                    </div>

                    <div class="buttons">
                        <!-- Bagian tombol aksi -->
                        <button type="submit" class="save"> Save Changes</button>
                        <!-- Tombol untuk menyimpan perubahan -->
                        <a href="profile.php" class="cancel-button">Cancel</a>
                        <!-- Tombol untuk membatalkan perubahan dan kembali ke halaman profil -->
                    </div>
                </form>

            </div>
        </form>
    </div>
</body>
</html>

<?php
mysqli_close($koneksi); // Menutup koneksi database
?>
