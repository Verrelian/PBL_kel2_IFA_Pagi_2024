<?php

// Nama File : payment_receipt1.php
// Deskripsi : Kode ini merupakan kode yang mengatur form resi yang ada di website kami
// Dibuat Oleh : Neli Fauziyah - 3312401007
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'pembeli'
// Jika bukan pembeli, arahkan ke halaman dashboard penjual
if ($_SESSION['type_user'] !== 'pembeli') {
    header("Location: dashboard_penjual.php"); // Dashboard penjual
    exit();
}

include("koneksi.php");

$id_transaksi = isset($_GET['id_transaksi']) ? $_GET['id_transaksi'] : '0';

try {
    // Query untuk mendapatkan data transaksi
    $query = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id_transaksi = '$id_transaksi'");

    if (!$query) {
        throw new Exception("Error executing query: " . mysqli_error($koneksi));
    }

    $row = mysqli_fetch_array($query);

    // Validate User ID
    if ($row) {
        $user_id = $row['user_id'];
        $user_query = mysqli_query($koneksi, "SELECT * FROM pembeli WHERE user_id = '$user_id'");

        if (!$user_query) {
            throw new Exception("Error executing user query: " . mysqli_error($koneksi));
        }

        $user_result = $user_query->num_rows;

        if ($user_result == 0) {
            // User ID not found in pengguna table
            echo "<script>
                    alert('User ID tidak valid. Transaksi tidak dapat diproses.');
                    window.location = 'dashboard.php';
                  </script>";
            exit();
        }
    } else {
        // Transaction not found
        echo "<script>
                alert('Transaksi tidak ditemukan.');
                window.location = 'dashboard.php';
              </script>";
        exit();
    }

    // Menghitung waktu sisa dalam detik (15 menit dikurangi waktu yang sudah lewat)
    date_default_timezone_set('Asia/Jakarta');  // Pastikan zona waktu Jakarta untuk server
    $start_time = strtotime($row['tanggal_transaksi']);
    $current_time = time();
    $time_left = (15 * 60) - ($current_time - $start_time);

    // Jika waktu sudah lewat 15 menit, set waktu sisa menjadi 0
    if ($time_left < 0) {
        $time_left = 0;
    }
} catch (Exception $e) {
    // Tangani kesalahan dan tampilkan pesan error
    echo "<script>
            alert('Terjadi kesalahan: " . $e->getMessage() . "');
            window.location = 'dashboard.php';
          </script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #B4B5BB;
        }

        .card {
            font-size: 16px;
            border: none;
            border-radius: 15px;
            background-color: #B4B5BB;
            padding: 25px;
            width: 550px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.25);
        }

        .info-box {
            background-color: #053bff58;
            color: white;
            border-radius: 10px;
            padding: 15px;
        }

        .qr-code-box {
            background-color: #e0e0e0;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
        }

        .qr-code-box img {
            width: 150px;
            height: 150px;
        }
    </style>
</head>

<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card">
        <h3 class="fw-bold">PAYMENT RECEIPT</h3>
        <div class="info-box my-3">
            <ul class="list-unstyled mb-0">
                <li><strong>ID Transaksi</strong><br>ID Transaksi : <?php echo $row['id_transaksi']; ?></li>
                <li><strong>User Data</strong><br>USER ID : <?php echo $row['user_id']; ?></li>
                <li class="mt-3"><strong>Payment Detail</strong><br> ITEM TYPE : <?php echo $row['nama_produk']; ?><br>
                    PAYMENT METHOD : <?php echo $row['metode_pembayaran']; ?><br>
                    PRICE : <?php echo 'Rp ' . number_format($row['harga_produk'], 0, ',', '.'); ?></li>
            </ul>
        </div>
        <p class="text-muted">Open m-banking or e-Wallet and scan the QR code to complete the payment</p>
        <h4 class="fw-bold text-center mt-4">SCAN QR CODE</h4>
        <div class="qr-code-box mx-auto mt-2">
            <img src="uploads/qr_code.png" alt="QR Code">
        </div>

        <!-- Countdown -->
        <div class="mt-3 text-center">
            <h5 id="countdown"></h5>
        </div>

        <button type="button" class="btn btn-secondary" onclick="history.back()">Back To Store</button>
    </div>

    <script>
        try {
            var timeLeft = <?php echo $time_left; ?>; // Dikirim dari PHP dalam detik

            // Pastikan timeLeft adalah angka valid
            if (isNaN(timeLeft) || timeLeft < 0) {
                throw new Error('Time left is invalid or negative.');
            }

            function updateCountdown() {
                try {
                    if (timeLeft >= 0) {
                        var minutes = Math.floor(timeLeft / 60); // hitung menit
                        var seconds = timeLeft % 60; // sisa detik
                        document.getElementById("countdown").innerText = "Time remaining: " + minutes + "m " + seconds + "s";
                        timeLeft--; // kurangi setiap detik
                    } else {
                        document.getElementById("countdown").innerText = "Time expired!";
                    }
                } catch (error) {
                    console.error('Error in countdown update:', error);
                    document.getElementById("countdown").innerText = "Error occurred!";
                }
            }

            setInterval(updateCountdown, 1000); // Update countdown setiap detik

        } catch (error) {
            console.error('Error initializing countdown:', error);
            document.getElementById("countdown").innerText = "Error occurred while initializing countdown.";
        }
    </script>
</body>

</html>