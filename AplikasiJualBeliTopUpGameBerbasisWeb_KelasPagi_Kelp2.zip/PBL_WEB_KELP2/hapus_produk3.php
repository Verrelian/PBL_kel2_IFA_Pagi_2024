<?php

// Nama File : hapus_produk3_penjual.php
// Deskripsi : Kode ini merupakan kode yang mengatur form CRUD dibagian Delete/hapus produk free fire
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 11-november-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'penjual'
// Jika bukan penjual, arahkan ke halaman dashboard pembeli
if ($_SESSION['type_user'] !== 'penjual') {
    header("Location: dashboard.php"); // Dashboard pembeli
    exit();
}

include 'koneksi.php';

// Pastikan ada parameter 'id' di URL
if (isset($_GET['id'])) {
    $produk_id = $_GET['id'];

    // Ambil data produk untuk mengetahui gambar yang terkait
    $query = "SELECT gambar FROM free_fire WHERE id_produk = '$produk_id'";

    // Tambahkan exception handling saat eksekusi query
    try {
        $result = mysqli_query($koneksi, $query);
        if (!$result) {
            throw new Exception('Query gagal: ' . mysqli_error($koneksi));
        }

        $data = mysqli_fetch_assoc($result);

        if ($data) {
            $gambar = $data['gambar'];

            // Hapus data produk dari database
            $deleteQuery = "DELETE FROM free_fire WHERE id_produk = '$produk_id'";

            // Tambahkan exception handling saat eksekusi query
            $deleteResult = mysqli_query($koneksi, $deleteQuery);
            if (!$deleteResult) {
                throw new Exception('Gagal menghapus produk: ' . mysqli_error($koneksi));
            }

            echo "<script>
                    alert('Produk berhasil dihapus');
                    window.location.href = 'produk3_penjual.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Produk tidak ditemukan');
                    window.location.href = 'produk3_penjual.php';
                  </script>";
        }
    } catch (Exception $e) {
        echo "<script>
                alert('Terjadi kesalahan: " . $e->getMessage() . "');
                window.location.href = 'produk3_penjual.php';
              </script>";
    }
} else {
    echo "<script>
            alert('ID produk tidak ditemukan');
            window.location.href = 'produk3_penjual.php';
          </script>";
}

mysqli_close($koneksi);
?>
