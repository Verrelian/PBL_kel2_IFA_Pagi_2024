// search.js

const games = [
    { id: 1, name: 'PUBG Mobile', image: 'pubg.jpg', description: 'Tencent Games', link: 'produk1_penjual.php' },
    { id: 2, name: 'Mobile Legends', image: 'mobile_legends.jpg', description: 'Moonton', link: 'produk2_penjual.php' },
    { id: 3, name: 'Free Fire', image: 'freefire.jpg', description: 'Garena', link: 'produk3_penjual.php' }
];

const searchInput = document.getElementById('searchInput');
const searchPopup = document.getElementById('searchPopup');
const searchOverlay = document.getElementById('searchOverlay');
const searchTerm = document.getElementById('searchTerm');
const searchResults = document.getElementById('searchResults');

function createGameElement(game) {
    return `
        <a href="${game.link}" class="search-result-item">
            <img src="${game.image}" alt="${game.name}" class="game-preview-img">
            <div class="game-info">
                <h2 class="game-preview-title">${game.name}</h2>
                <p>${game.description}</p>
            </div>
        </a>
    `;
}

function filterGames(searchTerm) {
    return games.filter(game =>
        game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        game.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
}

function updateSearchResults(searchTerm) {
    const filteredGames = filterGames(searchTerm);

    if (filteredGames.length === 0) {
        searchResults.innerHTML = '<div class="no-results">No games found</div>';
    } else {
        searchResults.innerHTML = filteredGames.map(game => createGameElement(game)).join('');
    }
}

searchInput.addEventListener('input', function () {
    if (this.value.length > 0) {
        searchPopup.classList.add('active');
        searchOverlay.classList.add('active');
        searchTerm.textContent = this.value;
        updateSearchResults(this.value);
    } else {
        searchPopup.classList.remove('active');
        searchOverlay.classList.remove('active');
    }
});

searchOverlay.addEventListener('click', function () {
    searchPopup.classList.remove('active');
    searchOverlay.classList.remove('active');
    searchInput.value = '';
});
