<?php
// Nama File : edit_produk3_penjual.php
// Deskripsi : Kode ini merupakan kode yang mengatur form CRUD dibagian ubah/edit produk free fire
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 11-november-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}
// Cek apakah tipe user yang login adalah 'penjual'
// Jika bukan penjual, arahkan ke halaman dashboard pembeli
if ($_SESSION['type_user'] !== 'penjual') {
    header("Location: dashboard.php"); // Dashboard pembeli
    exit();
}
// Koneksi ke database
include 'koneksi.php';

try {
    if (isset($_POST['id_produk']) && isset($_POST['nama_produk']) && isset($_POST['harga_produk'])) {
        // Ambil data dari form
        $id_produk = $_POST['id_produk'];
        $nama_produk = $_POST['nama_produk'];
        $harga_produk = $_POST['harga_produk'];
        $stock = $_POST['stok'];

        // Cek apakah ada gambar baru yang diupload
        if ($_FILES['gambar_produk']['name'] != '') {
            // Gambar baru diupload
            $gambar_produk = $_FILES['gambar_produk']['name'];
            $tmp_name = $_FILES['gambar_produk']['tmp_name'];
            $folder = 'uploads/';  // Folder tempat gambar disimpan
            $target = $folder . basename($gambar_produk);

            // Pastikan file berhasil dipindahkan ke folder tujuan
            if (move_uploaded_file($tmp_name, $target)) {
                // Update gambar baru di database
                $query = "UPDATE free_fire SET nama_produk='$nama_produk', harga_produk='$harga_produk', gambar='$target', stok='$stock' WHERE id_produk='$id_produk'";
            } else {
                // Jika gagal upload gambar
                throw new Exception("Gagal upload gambar.");
            }
        } else {
            // Jika gambar tidak diubah, gambar tetap yang lama
            $query = "UPDATE free_fire SET nama_produk='$nama_produk', harga_produk='$harga_produk', stok='$stock' WHERE id_produk='$id_produk'";
        }

        // Eksekusi query untuk update database
        if (!mysqli_query($koneksi, $query)) {
            throw new Exception("Gagal update produk: " . mysqli_error($koneksi));
        }

        echo "<script>
                alert('Produk berhasil diperbarui');
                window.location.href = 'produk3_penjual.php';
            </script>";
    } else {
        throw new Exception("Data tidak lengkap.");
    }
} catch (Exception $e) {
    echo "<script>
            alert('Terjadi kesalahan: " . $e->getMessage() . "');
            window.location.href = 'produk3_penjual.php';
          </script>";
} finally {
    // Tutup koneksi
    mysqli_close($koneksi);
}
?>
