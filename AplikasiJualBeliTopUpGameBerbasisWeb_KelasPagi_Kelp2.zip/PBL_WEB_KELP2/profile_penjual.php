<?php

// Nama File : profile_penjual.php
// Deskripsi : Kode ini digunakan untuk menampilkan profil penjual yang login di website.
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 02-Desember-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'penjual'
// Jika bukan penjual, arahkan ke halaman dashboard pembeli
if ($_SESSION['type_user'] !== 'penjual') {
    header("Location: dashboard.php"); // Dashboard pembeli
    exit();
}

include 'koneksi.php'; // Menghubungkan ke database

// Jika session 'username' dan 'user_id' sudah ada, lanjutkan untuk mengambil data profil
if (isset($_SESSION['username']) && isset($_SESSION['user_id'])) {
    $username = $_SESSION['username']; // Mendapatkan username dari session
    $user_id = $_SESSION['user_id'];  // Mendapatkan user_id dari session

    // Query untuk mengambil data pengguna berdasarkan user_id
    $query = "SELECT * FROM penjual WHERE user_id = '$user_id'";
    $result = mysqli_query($koneksi, $query);

    // Mengecek apakah data pengguna ditemukan
    if ($result && mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result); // Ambil data pengguna ke dalam array asosiatif
        $email = $data['email']; // Ambil email pengguna
        $inisial = strtoupper(substr($username, 0, 2)); // Ambil dua huruf pertama username untuk inisial
    } else {
        echo "Pengguna tidak ditemukan!"; // Jika tidak ada data yang ditemukan, tampilkan pesan
        exit(); // Stop eksekusi
    }
} else {
    header("Location: login.php"); // Jika tidak ada session 'username' atau 'user_id', arahkan ke login
    exit(); // Stop eksekusi jika session tidak valid
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link href="stylepr.css" rel="stylesheet"> <!-- Menyertakan file CSS untuk gaya tampilan -->
</head>
<body>
    <div class="card">
        <!-- Tombol Edit, mengarahkan ke halaman edit profile pengguna berdasarkan user_id -->
        <a href="editp.php?user_id=<?php echo $data['user_id']; ?>"><button class="edit-btn">Edit</button></a>

        <!-- Lingkaran Foto Profil dengan Inisial -->
        <div class="profile-circle">
            <?php echo $inisial; // Menampilkan dua huruf pertama sebagai inisial --> ?>
        </div>

        <!-- Menampilkan username -->
        <div class="username">
            <?php echo $username;  // Menampilkan username --> ?>
        </div>

        <div class="profile-info">
            <!-- Menampilkan User ID dan Email -->
            <div class="profile-item">
                <span>User ID</span>
                <span>: <?php echo $user_id; ?></span>
            </div>
            <div class="profile-item">
                <span>Email</span>
                <span>: <?php echo $email; ?></span>
            </div>
        </div>

        <!-- Tombol Log Out -->
        <form action="logout.php" method="post">
            <button type="submit" class="logout-btn">Log Out</button>
        </form>
    </div>

    <!-- Tombol Keluar untuk kembali ke dashboard penjual -->
    <a href="dashboard_penjual.php" class="button-keluar">Leave</a>
</body>
</html>
