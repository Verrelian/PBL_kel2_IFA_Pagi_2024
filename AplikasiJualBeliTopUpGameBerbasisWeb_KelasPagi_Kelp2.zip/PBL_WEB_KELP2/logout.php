<?php
// Nama File : logout.php
// Deskripsi : Kode ini merupakan kode yang mengatur form untuk logout disisi penjual maupun pembeli
// Dibuat Oleh : Firli Haniffurahman - 3312401029
// Tanggal Pembuatan : 08-november-2024

session_start(); // Mulai sesi

try {
    // Cek apakah pengguna sudah login berdasarkan keberadaan 'username' di session
    if (!isset($_SESSION['username'])) {
        // Jika pengguna belum login, arahkan mereka ke halaman login
        header("Location: login.php");
        exit(); // Pastikan kode setelah header tidak dieksekusi setelah redirect
    }

    // Hapus semua session data
    session_unset();

    // Hancurkan session
    session_destroy();

    // Menghapus cookie yang tersimpan jika ada (misalnya username atau type_user)
    if (isset($_COOKIE['username'])) {
        setcookie('username', '', time() - 3600, '/'); // Menghapus cookie dengan waktu expired yang sudah berlalu
    }
    if (isset($_COOKIE['type_user'])) {
        setcookie('type_user', '', time() - 3600, '/'); // Menghapus cookie
    }

    // Arahkan ke halaman login setelah logout
    header("Location: login.php");
    exit();
} catch (Exception $e) {
    // Menangani exception dan menampilkan pesan error jika terjadi
    echo "Terjadi kesalahan: " . $e->getMessage();
}
?>
