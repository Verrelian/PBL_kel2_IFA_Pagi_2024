<?php

// Nama File : produk3_pembeli.php
// Deskripsi : Kode ini merupakan kode yang menampilkan menu produk free_fire yang ada di website kami di sisi pembeli
// Dibuat Oleh : Vincent Bayu Pradya Putra - 3312401010
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'pembeli'
// Jika bukan pembeli, arahkan ke halaman dashboard penjual
if ($_SESSION['type_user'] !== 'pembeli') {
    header("Location: dashboard_penjual.php"); // Dashboard penjual
    exit();
}

include("koneksi.php");

$user_id_valid = false; // Flag untuk validasi user ID

// User validation
if (isset($_POST['Confirm'])) {
    try {
        // Cek jika user_id diterima
        if (isset($_POST['user_id'])) {
            $user_id = mysqli_real_escape_string($koneksi, $_POST['user_id']);
            $sql = "SELECT * FROM pembeli WHERE user_id = '$user_id'";
            $result = $koneksi->query($sql);

            // Cek apakah user_id valid
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $username = $row['username'];
                $email = $row['email'];
            } else {
                // Jika user_id tidak valid
                echo "<script>alert('User ID tidak ditemukan.');
                        window.location = 'produk3_pembeli.php';
                        </script>";
                exit(); // Hentikan eksekusi
            }
        }

        // Ambil data dari form dengan keamanan SQL Injection
        $user_id = mysqli_real_escape_string($koneksi, $_POST['user_id']);
        $product_data = mysqli_real_escape_string($koneksi, $_POST['product']); // Format: "Nama Produk|Harga Produk"
        $metode_pembayaran = mysqli_real_escape_string($koneksi, $_POST['payment_method']);

        // Pisahkan Nama Produk dan Harga Produk
        list($nama_produk, $harga_produk) = explode('|', $product_data);

        // Cek stok terlebih dahulu sebelum pemesanan
        $cek_stok = "SELECT stok FROM free_fire WHERE nama_produk = '$nama_produk'";
        $stok_result = mysqli_query($koneksi, $cek_stok);

        if ($stok_result) {
            $stok_data = mysqli_fetch_assoc($stok_result);

            if ($stok_data) {
                $stok_tersedia = $stok_data['stok'];  // Ambil stok produk

                // Validasi apakah stok cukup
                if ($stok_tersedia > 0) {
                    // Query untuk menyimpan data transaksi
                    $sql = "INSERT INTO transaksi (user_id, nama_produk, harga_produk, metode_pembayaran)
                            VALUES ('$user_id', '$nama_produk', '$harga_produk', '$metode_pembayaran')";
                    if (mysqli_query($koneksi, $sql)) {
                        // Ambil id transaksi yang baru dimasukkan
                        $id_transaksi = mysqli_insert_id($koneksi);

                        // Update stok produk hanya jika sukses simpan transaksi
                        $update_stok = "UPDATE free_fire SET stok = stok - 1 WHERE nama_produk = '$nama_produk'"; // Kurangi stok produk sebanyak 1
                        if (mysqli_query($koneksi, $update_stok)) {
                            // Berhasil mengurangi stok, arahkan ke halaman receipt
                            echo "<script>
                                    alert('Pesanan berhasil disimpan!');
                                    window.location = 'payment_receipt3.php?id_transaksi=" . $id_transaksi . "';
                                  </script>";
                        } else {
                            // Jika update stok gagal
                            throw new Exception('Gagal mengurangi stok produk.');
                        }
                    } else {
                        throw new Exception('Terjadi kesalahan saat menyimpan data transaksi: ' . mysqli_error($koneksi));
                    }
                } else {
                    // Jika stok produk tidak cukup (habis)
                    throw new Exception('Stok produk tidak cukup untuk pemesanan ini.');
                }
            } else {
                throw new Exception('Produk tidak ditemukan.');
            }
        } else {
            throw new Exception('Gagal memeriksa stok produk.');
        }
    } catch (Exception $e) {
        // Menangani error dan menampilkan pesan
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FREE FIRE Top Up</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="stylep.css" rel="stylesheet">
</head>

<body>
    <!-- Header Section -->
    <header class="header">
        <button class="header-menu-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
            aria-controls="offcanvasMenu">
            ☰
        </button>
        <div class="header-left">
            <div class="header-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
        </div>
    </header>

    <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu"
        aria-labelledby="offcanvasMenuLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasMenuLabel"><img src="btc.png" class="logo"></h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link text-white active">
                        <i class="fas fa-home"></i> HOME
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list_of_games.php" class="nav-link text-white">
                        <i class="fas fa-gamepad"></i> LIST OF GAMES
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link text-white">
                        <i class="fas fa-user"></i> ACCOUNT
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Header Image -->
    <div class="position-relative">
        <img src="freefire_banner.jpg" alt="FREE FIRE Characters Banner" class="header-image">
    </div>

    <!-- Main Content Container -->
    <div class="container position-relative">
        <!-- Game Logo and Title -->
        <div class="d-flex align-items-end mb-4">
            <img src="freefire.jpg" alt="FREE FIRE Logo" class="game-logo">
            <div class="text-white ms-3 mb-4">
                <h1 class="fs-2 fw-bold mb-0">FREE FIRE</h1>
                <p class="fs-5 mb-2">GARENA</p>
            </div>
        </div>

        <!-- Main Content Card -->
        <div class="main-content text-white p-4 mb-4">
            <div class="row">
                <!-- Left Side Grid Container -->
                <div class="col-md-3">
                    <div class="left-side-grid">
                        <h2 class="fw-bold fs-5 mb-2">Reminder</h2>
                        <ol class="fs-5 mb-2">
                            <li>Make sure the ID you entered is correct.</li>
                            <li>Then select the product you want to purchase.</li>
                            <li>Ensure it matches your preferences.</li>
                            <li>Confirm your purchase.</li>
                        </ol>
                    </div>
                </div>

                <!-- Right Side Vertical Grid Container -->
                <div class="col-md-9">
                    <div class="main-grid">
                        <!-- Account Input Section -->
                        <div class="grid-item">
                            <h3 class="fw-bold fs-5 mb-3">Enter Your Account Data</h3>
                            <input type="text" class="form-control user-id-input" placeholder="User ID">
                            <small class="text-white-help">Please enter your account User ID correctly.</small>
                        </div>

                        <!-- Product Selection Section -->
                        <div class="grid-item">
                            <h3 class="fw-bold fs-5 mb-3">Choose Product</h3>
                            <div class="products-grid">
                                <?php
                                try {
                                    include 'koneksi.php'; // Koneksi ke database

                                    // Query untuk mengambil data produk
                                    $query = mysqli_query($koneksi, "SELECT * FROM free_fire");
                                    if (!$query) {
                                        throw new Exception('Query gagal: ' . mysqli_error($koneksi));
                                    }

                                    while ($data = mysqli_fetch_assoc($query)) {
                                        $gambar = $data['gambar']; // Ambil path gambar dari database
                                        $stok = $data['stok']; // Ambil stok produk dari database
                                ?>
                                        <div class="product-card p-3 rounded">
                                            <!-- Ikon centang di pojok kanan atas -->
                                            <i class="fas fa-check product-check"></i>

                                            <div class="fw-bold"><?php echo $data['nama_produk']; ?></div>
                                            <div class="text-white-help">
                                                <?php echo "Rp " . number_format($data['harga_produk'], 0, ',', '.'); ?>
                                            </div>

                                            <!-- Cek apakah stok = 0 dan tambahkan overlay -->
                                            <?php if ($stok == 0): ?>
                                                <!-- Produk habis, tampilkan overlay -->
                                                <div class="out-of-stock-overlay">Stok Habis</div>
                                                <img src="<?php echo $data['gambar']; ?>" alt="error" class="out-of-stock-img">
                                            <?php else: ?>
                                                <!-- Produk tersedia, tampilkan gambar biasa -->
                                                <img src="<?php echo $data['gambar']; ?>" alt="error">
                                            <?php endif; ?>
                                        </div>
                                    <?php } ?>

                            </div>
                        </div>

                        <div class="grid-item">
                            <h3 class="fw-bold fs-5 mb-3">Payment Methods</h3>
                            <div class="products-grid">
                                <?php
                                    // Query untuk mengambil data metode pembayaran
                                    $query = mysqli_query($koneksi, "SELECT * FROM pembayaran");
                                    if (!$query) {
                                        throw new Exception('Query gagal: ' . mysqli_error($koneksi));
                                    }

                                    while ($data = mysqli_fetch_assoc($query)) {
                                ?>
                                    <div class="payment-card">
                                        <!-- Logo -->
                                        <img src="<?php echo $data['gambar']; ?>" alt="Payment Method Logo">
                                        <!-- Text -->
                                        <div class="payment-text"><?php echo $data['nama']; ?></div>
                                    </div>
                            <?php }
                                } catch (Exception $e) {
                                    echo "<script>alert('Terjadi kesalahan: " . $e->getMessage() . "');</script>";
                                }
                            ?>
                            </div>
                        </div>
                    </div>

                    <!-- Confirmation Section -->
                    <div>
                        <button class="confirm-button">Top Up Confirmation</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content card shadow-lg">
                <div class="modal-header border-0" style="background-color: #283593; color: white;">
                    <h3 class="modal-title fw-bold" id="orderModalLabel">Order Details</h3>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card p-4 shadow-sm">
                        <p class="card-text fs-5">Please verify the order details. If everything is correct,
                            click Confirm to proceed.</p>
                        <ul class="list-unstyled">
                            <li class="mb-3">
                                <strong>USER ID</strong><br>
                                <span id="modal-user-id" class="text-muted">#12345</span><br>
                                <strong>ITEM TYPE</strong><br>
                                <span id="modal-product" class="text-muted">Product Name</span><br>
                                <strong>PRICE</strong><br>
                                <span id="modal-price" class="text-success fs-4">$99.99</span><br>
                                <strong>PAYMENT METHOD</strong><br>
                                <span id="modal-payment-method" class="text-muted">Credit Card</span>
                            </li>
                        </ul>
                        <div class="d-flex justify-content-between align-items-center">
                            <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-confirm" name="Confirm">Confirm</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
            <div class="footer-text">
                <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store!</p>
            </div>
        </div>
        <p>© 2025 BTC Top Up Game Store. All Rights Reserved.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="jsp.js"></script>
</body>

</html>