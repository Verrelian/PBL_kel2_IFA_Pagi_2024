<?php
session_start(); // Memulai sesi untuk pengguna yang sudah login

// Nama File : pembaruan_password.php
// Deskripsi : Kode ini mengatur form pembaruan password di website
// Dibuat Oleh : Marsel Vicentius Paltakma Naibaho - 3312401005, disempurnakan oleh Wahyudi - 33124101014
// Tanggal Pembuatan : 02-desember-2024

// Menyertakan koneksi ke database
include 'koneksi.php';

// Cek apakah email untuk reset password disimpan di session
if (!isset($_SESSION['email_reset'])) {
    // Jika tidak ada email di session, alihkan ke halaman forgot_password.php
    header("Location: forgot_password.php");
    exit();
}

// Ambil email dari session untuk keperluan pembaruan password
$email = $_SESSION['email_reset'];

// Cek jika form di-submit (POST request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data password baru dan konfirmasi password dari form
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validasi untuk memastikan password baru dan konfirmasi cocok
    if ($newPassword !== $confirmPassword) {
        $error = "Password dan konfirmasi password tidak cocok."; // Jika password tidak sama
    } elseif (strlen($newPassword) < 6) {
        $error = "Password harus memiliki minimal 6 karakter."; // Validasi panjang password
    } else {
        // Jika validasi berhasil, hash password baru dan lakukan pembaruan password di database
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT); // Hash password

        // Menyiapkan query untuk memperbarui password berdasarkan email pengguna
        $stmt = $koneksi->prepare("UPDATE pembeli SET password = ? WHERE email = ?");
        if (!$stmt) {
            // Jika terjadi kesalahan pada query
            die("Query gagal: " . $koneksi->error);
        }

        // Binding parameter query
        $stmt->bind_param("ss", $hashedPassword, $email);

        // Eksekusi query untuk memperbarui password di database
        if ($stmt->execute()) {
            $success = "Password berhasil diperbarui."; // Pesan sukses
            session_destroy(); // Menghancurkan sesi setelah reset password sukses
            header("Location: login.php"); // Redirect ke halaman login
            exit(); // Pastikan kode setelah header tidak dijalankan
        } else {
            // Jika gagal memperbarui password
            $error = "Gagal memperbarui password.";
        }

        $stmt->close(); // Menutup prepared statement
    }
}

// Menutup koneksi database
$koneksi->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="icon" href="btc.png" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Password</title>
  <link rel="stylesheet" href="pembaruan_password_pembeli.css"> <!-- Tautkan file CSS untuk styling -->
</head>
<body>
  <div class="container">
    <!-- Logo perusahaan atau website -->
    <div class="logo">
      <img src="btc.png" alt="BTC Logo">
    </div>

    <h1>Reset Password</h1>

    <!-- Form untuk memasukkan password baru dan konfirmasi -->
    <form id="passwordForm" method="POST" action="">
      <!-- Input untuk password baru -->
      <input type="password" id="newPassword" name="newPassword" placeholder="Masukkan Password Baru" required>

      <!-- Input untuk konfirmasi password baru -->
      <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Konfirmasi Password Baru" required>

      <!-- Tombol untuk mengirim form -->
      <button type="submit">Reset Password</button>

      <!-- Menampilkan pesan error atau sukses jika ada -->
      <?php if (isset($error)): ?>
        <p class="message" style="color: #f44336;"><?= $error ?></p> <!-- Menampilkan pesan error jika ada -->
      <?php elseif (isset($success)): ?>
        <p class="message" style="color: #4caf50;"><?= $success ?></p> <!-- Menampilkan pesan sukses jika ada -->
      <?php endif; ?>
    </form>
  </div>
</body>
</html>
