<?php

// Nama File : produk3_penjual.php
// Deskripsi : Kode ini merupakan kode yang menampilkan menu produk free fire yang ada di website kami di sisi pembeli
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

try {
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['type_user'])) {
        // Pengguna belum login, arahkan ke halaman login
        throw new Exception("Pengguna belum login.");
    }

    // Cek apakah tipe user yang login adalah 'penjual'
    // Jika bukan penjual, arahkan ke halaman dashboard pembeli
    if ($_SESSION['type_user'] !== 'penjual') {
        throw new Exception("Tipe pengguna tidak sesuai. Hanya penjual yang dapat mengakses halaman ini.");
    }
} catch (Exception $e) {
    // Menangani exception jika terjadi
    echo "Terjadi kesalahan: " . $e->getMessage();
    header("Location: login.php"); // Redirect ke login jika terjadi kesalahan
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - FREE FIRE Top Up</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="style_penjual.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">

</head>

<body>

    <!-- Header Section -->
    <header class="header">
        <button class="header-menu-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
            aria-controls="offcanvasMenu">
            ☰
        </button>
        <div class="header-left">
            <div class="header-logo">
                <a href="dashboard_penjual.php">
                    <img src="btc.png" alt="BTC Logo">
                </a>
            </div>
        </div>
    </header>

    <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu"
        aria-labelledby="offcanvasMenuLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasMenuLabel"><img src="btc.png" class="logo"></h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="produk1_penjual.php" class="nav-link text-white">PUBG</a></li>
                <li class="nav-item"><a href="produk2_penjual.php" class="nav-link text-white">MOBILE LEGEND</a></li>
                <li class="nav-item"><a href="produk3_penjual.php" class="nav-link text-white">FREE FIRE</a></li>
            </ul>
        </div>
    </div>

    <div class="position-relative">
        <img src="freefire_banner.jpg" alt="FREE FIRE Characters Banner" class="header-image">
    </div>
    <div class="container position-relative">
        <div class="d-flex align-items-end mb-4">
            <img src="freefire.jpg" alt="FREE FIRE Logo" class="game-logo">
            <div class="text-white ms-3 mb-4">
                <h1 class="fs-2 fw-bold mb-0">FREE FIRE</h1>
                <p class="fs-5 mb-2">GARENA</p>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Produk -->
    <div class="modal fade" id="tambahDataModal" tabindex="-1" aria-labelledby="tambahDataLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tambahDataLabel">Tambah Data Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="tambah_produk3.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="nama" name="nama_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga Produk</label>
                            <input type="text" class="form-control" id="harga" name="harga_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-stok" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="edit-stok" name="stok" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-gambar" class="form-label">Gambar Produk</label>
                            <input type="file" class="form-control" id="edit-gambar" name="gambar_produk" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content text-white p-4 mb-4">
        <h3 class="fw-bold fs-5 mb-3">Edit Produk</h3>
        <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#tambahDataModal">
            <i class="fas fa-plus-circle me-2"></i>TAMBAH DATA PRODUK
        </button>
        <div class="products-grid">
            <?php
            include 'koneksi.php';

            try {
                // Query untuk mengambil data produk dari database
                $query = mysqli_query($koneksi, "SELECT * FROM free_fire");

                if (!$query) {
                    throw new Exception("Query gagal dijalankan: " . mysqli_error($koneksi));
                }

                while ($data = mysqli_fetch_assoc($query)) {
                    $gambar = $data['gambar'];
            ?>
                    <div class="product-card">
                        <img src="<?php echo $gambar; ?>" alt="Produk" class="img-fluid">
                        <div class="fw-bold mt-2"><?php echo $data['nama_produk']; ?></div>
                        <div class="text-white-help">Rp <?php echo number_format($data['harga_produk'], 0, ',', '.'); ?>
                            <div class="text-white-help">Stock : <?php echo $data['stok']; ?></div>
                        </div>
                        <button class="btn edit-button" data-bs-toggle="modal" data-bs-target="#editDataModal"
                            data-id="<?php echo $data['id_produk']; ?>" data-nama="<?php echo $data['nama_produk']; ?>"
                            data-harga="<?php echo $data['harga_produk']; ?>"
                            data-gambar="<?php echo $data['gambar']; ?>">Edit</button>
                        <a href="hapus_produk3.php?id=<?php echo $data['id_produk']; ?>" class="btn btn-danger mt-2"
                            onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Hapus</a>
                    </div>
            <?php
                }
            } catch (Exception $e) {
                // Menangani exception jika terjadi kesalahan pada query atau proses lainnya
                echo "Terjadi kesalahan: " . $e->getMessage();
                // Bisa menambahkan redirect atau menampilkan pesan yang lebih baik jika dibutuhkan
                header("Location: error_page.php"); // Mengarahkan ke halaman error
                exit();
            }
            ?>

        </div>
    </div>

    <div class="modal fade" id="editDataModal" tabindex="-1" aria-labelledby="editDataLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDataLabel">Edit Data Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="edit_produk3_penjual.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="edit-id" name="id_produk">
                        <div class="mb-3">
                            <label for="edit-nama" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="edit-nama" name="nama_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-harga" class="form-label">Harga Produk</label>
                            <input type="text" class="form-control" id="edit-harga" name="harga_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-stok" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="edit-stok" name="stok" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-gambar" class="form-label">Gambar Produk</label>
                            <input type="file" class="form-control" id="edit-gambar" name="gambar_produk">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
            <div class="footer-text">
                <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store!</p>
            </div>
        </div>
        <p>© 2025 BTC Top Up Game Store. All Rights Reserved.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editButtons = document.querySelectorAll('.edit-button');
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    try {
                        const id = this.getAttribute('data-id');
                        const nama = this.getAttribute('data-nama');
                        const harga = this.getAttribute('data-harga');
                        const stok = this.getAttribute('data-stok');
                        const gambar = this.getAttribute('data-gambar');

                        console.log('Product ID:', id);
                        console.log('Product Name:', nama);
                        console.log('Product Price:', harga);

                        const editIdInput = document.getElementById('edit-id');
                        const editNamaInput = document.getElementById('edit-nama');
                        const editHargaInput = document.getElementById('edit-harga');
                        const editStokInput = document.getElementById('edit-stok');
                        const gambarPreview = document.getElementById('gambar-preview');

                        if (editIdInput) {
                            editIdInput.value = id;
                        } else {
                            throw new Error('Edit ID input not found');
                        }

                        if (editNamaInput) {
                            editNamaInput.value = nama;
                        } else {
                            throw new Error('Edit Name input not found');
                        }

                        if (editHargaInput) {
                            editHargaInput.value = harga;
                        } else {
                            throw new Error('Edit Price input not found');
                        }

                        if (gambarPreview) {
                            gambarPreview.src = gambar ? gambar : 'default_image.jpg'; // Menampilkan gambar sebelumnya atau default jika tidak ada
                        }

                    } catch (error) {
                        console.error('Error:', error.message);
                        alert('Terjadi kesalahan: ' + error.message);
                    }
                });
            });
        });
    </script>
</body>

</html>