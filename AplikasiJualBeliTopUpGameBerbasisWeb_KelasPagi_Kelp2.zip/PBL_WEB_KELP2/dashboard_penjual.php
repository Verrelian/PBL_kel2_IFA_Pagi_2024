<?php
// Nama File : dashboard_penjual.php
// Deskripsi : Kode ini merupakan kode yang menampilkan konten dashboard dari sisi penjual
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 22-Desember-2024

session_start();

try {
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['type_user'])) {
        // Pengguna belum login, arahkan ke halaman login
        header("Location: login.php");
        exit();
    }

    // Cek apakah tipe user yang login adalah 'penjual'
    // Jika bukan penjual, arahkan ke halaman dashboard pembeli
    if ($_SESSION['type_user'] !== 'penjual') {
        header("Location: dashboard.php"); // Dashboard pembeli
        exit();
    }
} catch (Exception $e) {
    // Tangani error terkait sesi atau pengalihan
    error_log("Error pada dashboard_penjual.php: " . $e->getMessage(), 3, "error_log.txt");
    echo "Terjadi kesalahan. Silakan coba lagi nanti.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="btc.png" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <link href="styled.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">
  <title>BTC Top Up Game Store</title>
</head>

<body>
  <!-- Button untuk membuka menu offcanvas -->
  <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu" aria-controls="offcanvasMenu">
    &#9776;
  </button>

  <!-- Offcanvas Menu -->
  <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasMenuLabel">
        <img src="btc.png" class="logo" alt="BTC Logo">
      </h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <!-- Navigation Links -->
      <ul class="nav flex-column">
        <li class="nav-item">
          <a href="dashboard_penjual.php" class="nav-link text-white active">
            <i class="fas fa-home"></i> HOME
          </a>
        </li>
        <li class="nav-item">
          <a href="list_of_gamesp.php" class="nav-link text-white">
            <i class="fas fa-gamepad"></i> LIST OF GAMES
          </a>
        </li>
        <li class="nav-item">
          <a href="profile_penjual.php" class="nav-link text-white">
            <i class="fas fa-user"></i> ACCOUNT
          </a>
        </li>
      </ul>
    </div>
  </div>

  <!-- Header Section -->
  <header class="header">
    <div class="header-left">
      <div class="header-logo">
        <img src="btc.png" alt="BTC Logo">
      </div>
      <div class="search-bar">
        <input type="text" placeholder="Search Game" id="searchInput">
      </div>
    </div>
  </header>

  <!-- Search Popup -->
  <div class="search-overlay" id="searchOverlay"></div>
  <div class="search-popup" id="searchPopup">
    <div class="search-popup-header">
      <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
      </svg>
      <h3 id="searchTerm"></h3>
    </div>
    <div class="search-results" id="searchResults">
      <!-- Hasil pencarian akan ditampilkan di sini -->
    </div>
  </div>

  <!-- Banner Section -->
  <section class="banner"></section>

  <!-- Divider -->
  <div class="divider">
    <h2>Daftar Game</h2>
  </div>

  <!-- Game List Section -->
  <section class="game-list">
    <?php
    // Daftar game yang akan ditampilkan
    $games = [
      ['name' => 'PUBG Mobile', 'image' => 'pubg.jpg', 'description' => 'Tencent Games', 'link' => 'produk1_penjual.php'],
      ['name' => 'Mobile Legends', 'image' => 'mobile_legends.jpg', 'description' => 'Moonton', 'link' => 'produk2_penjual.php'],
      ['name' => 'Free Fire', 'image' => 'freefire.jpg', 'description' => 'Garena', 'link' => 'produk3_penjual.php']
    ];

    // Render setiap game dalam list
    foreach ($games as $game) : ?>
      <div class="game-item">
        <a href="<?= $game['link'] ?>">
          <img src="<?= $game['image'] ?>" alt="<?= $game['name'] ?>">
          <div class="game-info">
            <h2 class="game-title"><?= $game['name'] ?></h2>
            <p class="game-subtitle"><?= $game['description'] ?></p>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </section>

  <!-- Footer Section -->
  <footer>
    <div class="footer-content">
      <div class="footer-logo">
        <img src="btc.png" alt="BTC Logo">
      </div>
      <div class="footer-text">
        <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store!</p>
      </div>
    </div>
    <p>&copy; 2025 BTC Top Up Game Store. All Rights Reserved.</p>
  </footer>

  <!-- Script Section -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Jsd.js adalah file yang mengatur fitur popup pencarian -->
  <script src="js_dashboard.js"></script>
</body>

</html>
