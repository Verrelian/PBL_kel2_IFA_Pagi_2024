<?php
session_start(); // Mulai sesi

// Nama File : hapus_produk1_penjual.php
// Deskripsi : Kode ini merupakan kode yang mengatur form CRUD dibagian Delete/hapus produk pubg
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 11-november-2024

include 'koneksi.php';

// Cek apakah pengguna sudah login berdasarkan keberadaan 'username' di session
if (!isset($_SESSION['username'])) {
    // Jika pengguna belum login, arahkan mereka ke halaman login
    header("Location: login.php");
    exit(); // Pastikan kode setelah header tidak dieksekusi setelah redirect
}

// Pastikan ada parameter 'id' di URL
if (isset($_GET['id'])) {
    $produk_id = $_GET['id'];

    // Ambil data produk untuk mengetahui gambar yang terkait
    $query = "SELECT gambar FROM pubg WHERE id_produk = '$produk_id'";

    // Pengecekan koneksi dan eksekusi query
    if ($result = mysqli_query($koneksi, $query)) {
        $data = mysqli_fetch_assoc($result);

        if ($data) {
            $gambar = $data['gambar'];

            // Hapus data produk dari database
            $deleteQuery = "DELETE FROM pubg WHERE id_produk = '$produk_id'";

            // Eksekusi query hapus
            if (mysqli_query($koneksi, $deleteQuery)) {
                echo "<script>
                        alert('Produk berhasil dihapus');
                        window.location.href = 'produk1_penjual.php';
                    </script>";
            } else {
                // Menangani error pada saat query delete gagal
                echo "<script>
                        alert('Gagal menghapus produk: " . mysqli_error($koneksi) . "');
                        window.location.href = 'produk1_penjual.php';
                    </script>";
            }
        } else {
            // Menangani jika data produk tidak ditemukan
            echo "<script>
                    alert('Produk tidak ditemukan');
                    window.location.href = 'produk1_penjual.php';
                </script>";
        }
    } else {
        // Menangani jika query untuk mengambil gambar gagal
        echo "<script>
                alert('Gagal memproses permintaan: " . mysqli_error($koneksi) . "');
                window.location.href = 'produk1_penjual.php';
            </script>";
    }
} else {
    // Menangani jika parameter id tidak ada di URL
    echo "<script>
            alert('ID produk tidak ditemukan');
            window.location.href = 'produk1_penjual.php';
        </script>";
}

mysqli_close($koneksi);
?>
