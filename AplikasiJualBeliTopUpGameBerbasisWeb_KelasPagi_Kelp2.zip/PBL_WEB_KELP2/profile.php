<?php

// Nama File : profile.php
// Deskripsi : Kode ini merupakan kode yang menampilkan menu profil akun yang ada di website kami di sisi pembeli
// Dibuat Oleh : Firli Haniffurahman - 3312401029 disempurnakan oleh Wahyudi - 3312401014
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'pembeli'
// Jika bukan pembeli, arahkan ke halaman dashboard penjual
if ($_SESSION['type_user'] !== 'pembeli') {
    header("Location: dashboard_penjual.php"); // Dashboard penjual
    exit();
}

include 'koneksi.php'; // Menghubungkan ke database

// Pastikan pengguna sudah login (memeriksa session)
if (isset($_SESSION['username']) && isset($_SESSION['user_id'])) {
    $username = $_SESSION['username']; // Menyimpan username dari session
    $user_id = $_SESSION['user_id'];   // Menyimpan user_id dari session yang sudah diperbarui

    try {
        // Ambil data pengguna berdasarkan user_id yang sudah ada di session
        $query = "SELECT * FROM pembeli WHERE user_id = '$user_id'";
        $result = mysqli_query($koneksi, $query); // Menjalankan query untuk mengambil data pengguna

        if ($result && mysqli_num_rows($result) > 0) {
            // Jika hasil query ada, ambil data pengguna
            $data = mysqli_fetch_assoc($result);
            $email = $data['email']; // Menyimpan email dari data pengguna
            $inisial = strtoupper(substr($username, 0, 2)); // Membuat inisial dua huruf pertama dari username
        } else {
            // Jika pengguna tidak ditemukan
            throw new Exception("Pengguna tidak ditemukan!");
        }
    } catch (Exception $e) {
        // Tangkap dan tampilkan pesan error
        echo "Error: " . $e->getMessage();
        exit();
    }
} else {
    header("Location: login.php"); // Jika pengguna belum login, arahkan ke login
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link href="stylepr.css" rel="stylesheet"> <!-- Menghubungkan CSS untuk halaman profil -->
</head>
<body>
    <div class="card">
        <!-- Tombol Edit -->
        <a href="edit.php?user_id=<?php echo $data['user_id']; ?>"><button class="edit-btn">Edit</button></a> <!-- Link menuju halaman edit -->

        <!-- Lingkaran Foto Profil dengan Inisial -->
        <div class="profile-circle">
            <?php echo $inisial; // Menampilkan inisial pengguna ?>
        </div>

        <!-- Menampilkan Username Pengguna -->
        <div class="username">
            <?php echo $username; ?>
        </div>

        <div class="profile-info">
            <div class="profile-item">
                <span>User ID</span>
                <span>: <?php echo $user_id; ?></span>
            </div>
            <div class="profile-item">
                <span>Email</span>
                <span>: <?php echo $email; ?></span>
            </div>
        </div>

        <!-- Tombol Log Out -->
        <form action="logout.php" method="post">
            <button type="submit" class="logout-btn">Log Out</button> <!-- Tombol untuk logout -->
        </form>
    </div>

    <!-- Tombol Keluar yang diletakkan di pojok kiri bawah -->
    <a href="dashboard.php" class="button-keluar">Leave</a> <!-- Tombol untuk kembali ke dashboard -->
</body>

</html>
