<?php
// Nama File : forgot_password.php
// Deskripsi : Kode ini merupakan kode yang mengatur form forgot password
// Dibuat Oleh : Marsel Vicentius Paltakma Naibaho - 3312401005 disempurnakan oleh Wahyudi - 3312401014
// Tanggal Pembuatan : 08-november-2024

session_start(); // Mulai sesi

include 'koneksi.php'; // Menghubungkan ke database menggunakan file koneksi.php

// Mengecek apakah request yang diterima adalah POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Mengambil data yang dikirim oleh form (username dan email)
        $username = $_POST['username'];
        $email = $_POST['email'];

        // Menyiapkan query untuk memeriksa apakah kombinasi username dan email ada di database
        $stmt = $koneksi->prepare("SELECT username FROM pembeli WHERE username = ? AND email = ?");

        if (!$stmt) {
            // Jika query gagal disiapkan, lempar exception
            throw new Exception("Query gagal: " . $koneksi->error);
        }

        // Mengikat parameter username dan email ke query, menggunakan tipe data string (ss)
        $stmt->bind_param("ss", $username, $email);

        // Menjalankan query
        $stmt->execute();

        // Mendapatkan hasil dari query yang dieksekusi
        $result = $stmt->get_result();

        // Mengecek apakah ada hasil (kombinasi username dan email ditemukan di database)
        if ($result->num_rows > 0) {
            // Jika ditemukan, menyimpan username dan email di session untuk digunakan di halaman selanjutnya
            $_SESSION['username_reset'] = $username;
            $_SESSION['email_reset'] = $email;

            // Melakukan redirect ke halaman reset password setelah session diset
            header("Location: pembaruan_password_pembeli.php");
            exit(); // Pastikan setelah redirect tidak ada kode yang dieksekusi
        } else {
            // Jika kombinasi username dan email tidak ditemukan di database, tampilkan pesan error
            $error = "Username atau email tidak valid.";
        }

        $stmt->close(); // Menutup prepared statement setelah selesai digunakan
    } catch (Exception $e) {
        // Menangani exception dan menampilkan pesan error
        echo "Terjadi kesalahan: " . $e->getMessage();
    }
}

$koneksi->close(); // Menutup koneksi ke database setelah proses selesai
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .gradient-background {
            background: linear-gradient(180deg, #282568 0%, #4F49CE 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        .logo {
            width: 100px;
            height: auto;
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .custom-input {
            border-radius: 50px;
            padding: 10px 12px;
            background-color: rgba(255, 255, 255, 0.9);
        }

        .custom-button {
            background: #424242;
            color: white;
            padding: 10px 30px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 16px;
        }

        .custom-button:hover {
            background-color: #555555;
        }

        .page-title {
            color: white;
            font-size: 2.5rem;
            font-weight: 600;
        }

        .input-label {
            color: white;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="gradient-background">
        <img src="btc.png" alt="BTC Logo" class="logo">
        <div class="container text-center">
        <div class="container text-center mt-5">
        <h1>Forgot Password?</h1>
        <form method="POST" action="">
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Masukkan Username Anda" required>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" name="email" class="form-control" placeholder="Masukkan Email Anda" required>
    </div>
    <button type="submit" class="btn btn-primary">Next</button>
</form>

        <?php if (isset($error)): ?>
            <p class="text-danger mt-3"><?= $error ?></p>
        <?php endif; ?>
    </div>
</form>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
