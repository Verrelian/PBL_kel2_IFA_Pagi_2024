<?php

// Nama File : produk2_penjual.php
// Deskripsi : Kode ini menampilkan menu produk Mobile Legends di website kami di sisi penjual
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

try {
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['type_user'])) {
        // Pengguna belum login, arahkan ke halaman login
        header("Location: login.php");
        exit();
    }

    // Cek apakah tipe user yang login adalah 'penjual'
    // Jika bukan penjual, arahkan ke halaman dashboard pembeli
    if ($_SESSION['type_user'] !== 'penjual') {
        header("Location: dashboard.php"); // Dashboard pembeli
        exit();
    }
} catch (Exception $e) {
    // Tangani error terkait sesi atau pengalihan
    error_log("Error pada produk2_penjual.php: " . $e->getMessage(), 3, "error_log.txt");
    echo "Terjadi kesalahan. Silakan coba lagi nanti.";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - MOBILE LEGEND Top Up</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="style_penjual.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">
</head>

<body>

    <!-- Header Section -->
    <header class="header">
        <button class="header-menu-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
            aria-controls="offcanvasMenu">
            ☰
        </button>
        <div class="header-left">
            <div class="header-logo">
                <a href="dashboard_penjual.php">
                    <img src="btc.png" alt="BTC Logo">
                </a>
            </div>
        </div>
    </header>

    <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu"
        aria-labelledby="offcanvasMenuLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasMenuLabel"><img src="btc.png" class="logo"></h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="produk1_penjual.php" class="nav-link text-white">PUBG</a></li>
                <li class="nav-item"><a href="produk2_penjual.php" class="nav-link text-white">MOBILE LEGEND</a></li>
                <li class="nav-item"><a href="produk3_penjual.php" class="nav-link text-white">FREE FIRE</a></li>
            </ul>
        </div>
    </div>

    <div class="position-relative">
        <img src="mobile_legends_banner.jpeg" alt="MOBILE LEGEND Characters Banner" class="header-image">
    </div>
    <div class="container position-relative">
        <div class="d-flex align-items-end mb-4">
            <img src="mobile_legends.jpg" alt="MOBILE LEGEND Logo" class="game-logo">
            <div class="text-white ms-3 mb-4">
                <h1 class="fs-2 fw-bold mb-0">MOBILE LEGEND</h1>
                <p class="fs-5 mb-2">MOONTON</p>
            </div>
        </div>
    </div>


    <!-- Modal Tambah Produk -->
    <div class="modal fade" id="tambahDataModal" tabindex="-1" aria-labelledby="tambahDataLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tambahDataLabel">Tambah Data Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="tambah_produk2.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="nama" name="nama_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga Produk</label>
                            <input type="text" class="form-control" id="harga" name="harga_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-stok" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="edit-stok" name="stok" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-gambar" class="form-label">Gambar Produk</label>
                            <input type="file" class="form-control" id="edit-gambar" name="gambar_produk" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content text-white p-4 mb-4">
        <h3 class="fw-bold fs-5 mb-3">Edit Produk</h3>
        <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#tambahDataModal">
            <i class="fas fa-plus-circle me-2"></i>TAMBAH DATA PRODUK
        </button>
        <div class="products-grid">
            <?php
            include 'koneksi.php';

            try {
                // Pastikan koneksi berhasil
                if (!$koneksi) {
                    throw new Exception('Koneksi ke database gagal: ' . mysqli_connect_error());
                }

                $query = mysqli_query($koneksi, "SELECT * FROM mobile_legends");

                // Cek apakah query berhasil dijalankan
                if (!$query) {
                    throw new Exception('Query gagal dijalankan: ' . mysqli_error($koneksi));
                }

                while ($data = mysqli_fetch_assoc($query)) {
                    $gambar = $data['gambar'];
            ?>
                    <div class="product-card">
                        <img src="<?php echo htmlspecialchars($gambar); ?>" alt="Produk" class="img-fluid">
                        <div class="fw-bold mt-2"><?php echo htmlspecialchars($data['nama_produk']); ?></div>
                        <div class="text-white-help">Rp <?php echo number_format($data['harga_produk'], 0, ',', '.'); ?>
                            <div class="text-white-help">Stock : <?php echo $data['stok']; ?></div>
                        </div>
                        <button class="btn edit-button" data-bs-toggle="modal" data-bs-target="#editDataModal"
                            data-id="<?php echo $data['id_produk']; ?>" data-nama="<?php echo $data['nama_produk']; ?>"
                            data-harga="<?php echo $data['harga_produk']; ?>"
                            data-gambar="<?php echo $data['gambar']; ?>">Edit</button>
                        <a href="hapus_produk2.php?id=<?php echo $data['id_produk']; ?>" class="btn btn-danger mt-2"
                            onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Hapus</a>
                    </div>
            <?php
                }
            } catch (Exception $e) {
                // Tangani error
                error_log("Error pada produk2_penjual.php: " . $e->getMessage(), 3, "error_log.txt");
                echo "Terjadi kesalahan. Silakan coba lagi nanti.";
                exit();
            }
            ?>
        </div>
    </div>


    <div class="modal fade" id="editDataModal" tabindex="-1" aria-labelledby="editDataLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDataLabel">Edit Data Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="edit_produk2_penjual.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="edit-id" name="id_produk">
                        <div class="mb-3">
                            <label for="edit-nama" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="edit-nama" name="nama_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-harga" class="form-label">Harga Produk</label>
                            <input type="text" class="form-control" id="edit-harga" name="harga_produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-stok" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="edit-stok" name="stok" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-gambar" class="form-label">Gambar Produk</label>
                            <input type="file" class="form-control" id="edit-gambar" name="gambar_produk">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
            <div class="footer-text">
                <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store!</p>
            </div>
        </div>
        <p>© 2025 BTC Top Up Game Store. All Rights Reserved.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            try {
                const editButtons = document.querySelectorAll('.edit-button');
                if (editButtons.length === 0) {
                    console.warn('No edit buttons found');
                }
                editButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        try {
                            const id = this.getAttribute('data-id');
                            const nama = this.getAttribute('data-nama');
                            const harga = this.getAttribute('data-harga');
                            const stok = this.getAttribute('data-stok');
                            const gambar = this.getAttribute('data-gambar');

                            console.log('Product ID:', id);
                            console.log('Product Name:', nama);
                            console.log('Product Price:', harga);

                            const editIdInput = document.getElementById('edit-id');
                            const editNamaInput = document.getElementById('edit-nama');
                            const editHargaInput = document.getElementById('edit-harga');
                            const editStokInput = document.getElementById('edit-stok');
                            const gambarPreview = document.getElementById('gambar-preview');

                            if (editIdInput) {
                                editIdInput.value = id;
                            } else {
                                console.error('Edit ID input not found');
                            }

                            if (editNamaInput) {
                                editNamaInput.value = nama;
                            } else {
                                console.error('Edit Name input not found');
                            }

                            if (editHargaInput) {
                                editHargaInput.value = harga;
                            } else {
                                console.error('Edit Price input not found');
                            }

                            if (editStokInput) {
                                editStokInput.value = stok;
                            } else {
                                console.error('Edit Stock input not found');
                            }

                            if (gambarPreview) {
                                gambarPreview.src = gambar ? gambar : 'default_image.jpg'; // Menampilkan gambar sebelumnya atau default jika tidak ada
                            } else {
                                console.error('Image preview element not found');
                            }
                        } catch (error) {
                            console.error('Error in click event:', error.message);
                        }
                    });
                });
            } catch (error) {
                console.error('Error initializing edit buttons:', error.message);
            }
        });
    </script>
</body>

</html>