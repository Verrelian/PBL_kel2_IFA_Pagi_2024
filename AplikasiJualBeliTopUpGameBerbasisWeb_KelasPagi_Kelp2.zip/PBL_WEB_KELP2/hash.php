<?php
// Koneksi ke database
include 'koneksi.php';  // Sesuaikan dengan file koneksi Anda

$username = 'adminbtc';  // Username yang ingin diubah password-nya

try {
    // Query untuk mengambil password lama
    $query = "SELECT password FROM penjual WHERE username = '$username'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        // Jika query gagal, lempar exception
        throw new Exception("Query gagal: " . mysqli_error($koneksi));
    }

    if (mysqli_num_rows($result) > 0) {
        // Ambil password lama yang belum di-hash
        $row = mysqli_fetch_assoc($result);
        $plain_password = $row['password'];  // Password yang belum di-hash

        // Hash password menggunakan password_hash()
        $hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

        // Update password dengan password yang sudah di-hash
        $update_query = "UPDATE penjual SET password = '$hashed_password' WHERE username = '$username'";

        if (mysqli_query($koneksi, $update_query)) {
            echo "Password berhasil diperbarui dengan hash.";
        } else {
            echo "Gagal memperbarui password.";
        }
    } else {
        echo "Username tidak ditemukan.";
    }
} catch (Exception $e) {
    // Menangani exception dan menampilkan pesan error
    echo "Terjadi kesalahan: " . $e->getMessage();
}
?>
