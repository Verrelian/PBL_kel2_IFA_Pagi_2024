<?php
// Nama File : dashboard.php
// Deskripsi : Kode ini merupakan kode yang menampilkan konten dashboard dari sisi pembeli
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 02-Desember-2024

try {
    session_start(); // Mulai sesi

    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['type_user'])) {
        // Pengguna belum login, arahkan ke halaman login
        header("Location: login.php");
        exit();
    }

    // Cek apakah tipe user yang login adalah 'pembeli'
    // Jika bukan pembeli, arahkan ke halaman dashboard penjual
    if ($_SESSION['type_user'] !== 'pembeli') {
        header("Location: dashboard_penjual.php"); // Dashboard penjual
        exit();
    }
} catch (Exception $e) {
    // Tangani error terkait sesi atau pengalihan
    error_log("Error pada dashboard.php: " . $e->getMessage(), 3, "error_log.txt");
    echo "Terjadi kesalahan. Silakan coba lagi nanti.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <link rel="icon" href="btc.png" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <link href="styled.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">


  <title>BTC Top Up Game Store</title>

</head>

<body>

  <!-- Header Section -->
  <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
    aria-controls="offcanvasMenu">
    ☰
  </button>
  <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasMenuLabel">
            <img src="btc.png" class="logo" alt="BTC Logo">
        </h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
  <ul class="nav flex-column">
    <li class="nav-item">
      <a href="dashboard.php" class="nav-link text-white active">
        <i class="fas fa-home"></i> HOME
      </a>
    </li>
    <li class="nav-item">
      <a href="list_of_games.php" class="nav-link text-white">
        <i class="fas fa-gamepad"></i> LIST OF GAMES
      </a>
    </li>
    <li class="nav-item">
      <a href="profile.php" class="nav-link text-white">
        <i class="fas fa-user"></i> ACCOUNT
      </a>
    </li>
  </ul>
</div>

</div>

  <header class="header">
    <div class="header-left">
      <div class="header-logo">
        <img src="btc.png" alt="BTC Logo">
      </div>
      <div class="search-bar">
        <input type="text" placeholder="Search Game" id="searchInput">
      </div>
    </div>
  </header>

  <!-- Search Popup -->
  <div class="search-overlay" id="searchOverlay"></div>
  <div class="search-popup" id="searchPopup">
    <div class="search-popup-header">
      <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
      </svg>
      <h3 id="searchTerm"></h3>
    </div>
    <div class="search-results" id="searchResults">
      <!-- Search results will be inserted here -->
    </div>
  </div>

  <!-- Banner Section -->
  <section class="banner">
  </section>

  <div class="divider">
    <h2>Daftar Game</h2>
  </div>

<!-- Game List Section -->
<section class="game-list">
  <!-- Game Item 1 -->
  <div class="game-item">
    <a href="produk1_pembeli.php">
      <img src="pubg.jpg" alt="PUBG">
      <div class="game-info">
        <h2 class="game-title">PUBG Mobile</h2> <!-- Teks di atas -->
        <p class="game-subtitle">Tencent Games</p> <!-- Teks di bawah -->
      </div>
    </a>
  </div>

  <!-- Game Item 2 -->
  <div class="game-item" data-description="PUBG - Game battle royale action">
    <a href="produk2_pembeli.php">
      <img src="mobile_legends.jpg" alt="Mobile Legends">
      <div class="game-info">
        <h2 class="game-title">Mobile Legends</h2> <!-- Teks di atas -->
        <p class="game-subtitle">Moonton</p> <!-- Teks di bawah -->
      </div>
    </a>
  </div>

  <!-- Game Item 3 -->
  <div class="game-item">
    <a href="produk3_pembeli.php">
      <img src="freefire.jpg" alt="Free Fire">
      <div class="game-info">
        <h2 class="game-title">Free Fire</h2> <!-- Teks di atas -->
        <p class="game-subtitle">Garena</p> <!-- Teks di bawah -->
      </div>
    </a>
  </div>
</section>


  <!-- Footer Section -->
  <footer>
    <div class="footer-content">
      <div class="footer-logo">
        <img src="btc.png" alt="BTC Logo">
      </div>
      <div class="footer-text">
        <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store!</p>
      </div>
    </div>
    <p>© 2025 BTC Top Up Game Store. All Right Reserved.</p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- js ini mengatur fitur popup pencarian-->
  <script src="js_dashboardp.js"></script>

</body>

</html>