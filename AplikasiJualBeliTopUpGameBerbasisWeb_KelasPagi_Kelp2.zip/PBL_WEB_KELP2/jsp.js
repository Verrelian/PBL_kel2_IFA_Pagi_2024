document.addEventListener('DOMContentLoaded', () => {
    try {
        const productCards = document.querySelectorAll('.product-card');
        const paymentCards = document.querySelectorAll('.payment-card');
        const userIdInput = document.querySelector('.user-id-input');
        const confirmButton = document.querySelector('.confirm-button');
        const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));

        let selectedProduct = null;
        let selectedPaymentMethod = null;

        // Product Selection
        productCards.forEach((card) => {
            card.addEventListener('click', () => {
                try {
                    // Remove active state from all product cards
                    productCards.forEach(c => c.classList.remove('active'));

                    // Add active state to selected card
                    card.classList.add('active');

                    // Get product details
                    const productName = card.querySelector('.fw-bold').textContent;
                    const productPrice = card.querySelector('.text-white-help').textContent;

                    // Store selected product
                    selectedProduct = {
                        name: productName,
                        price: productPrice
                    };

                    // Update modal preview
                    updateModalPreview();
                } catch (error) {
                    console.error('Error in product selection:', error);
                    alert('An error occurred while selecting the product.');
                }
            });
        });

        // Payment Method Selection
        paymentCards.forEach((card) => {
            card.addEventListener('click', () => {
                try {
                    // Remove active state from all payment cards
                    paymentCards.forEach(c => c.classList.remove('active'));

                    // Add active state to selected card
                    card.classList.add('active');

                    // Get payment method name
                    const paymentMethodName = card.querySelector('.payment-text').textContent;

                    // Store selected payment method
                    selectedPaymentMethod = paymentMethodName;

                    // Update modal preview
                    updateModalPreview();
                } catch (error) {
                    console.error('Error in payment method selection:', error);
                    alert('An error occurred while selecting the payment method.');
                }
            });
        });

        // Confirmation Button
        confirmButton.addEventListener('click', () => {
            try {
                // Check if all required fields are filled
                if (!userIdInput.value) {
                    alert('Please enter your User ID');
                    return;
                }

                if (!selectedProduct) {
                    alert('Please select a product');
                    return;
                }

                if (!selectedPaymentMethod) {
                    alert('Please select a payment method');
                    return;
                }

                // Show the modal
                updateModalPreview();
                modal.show();
            } catch (error) {
                console.error('Error in confirmation button:', error);
                alert('An error occurred while confirming your selection.');
            }
        });

        // Modal Confirmation Handler
        const modalConfirmButton = document.querySelector('.modal-dialog .btn-confirm');
        modalConfirmButton.addEventListener('click', () => {
            try {
                // Create form submission
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = ''; // Current page

                // User ID input
                const userIdField = document.createElement('input');
                userIdField.type = 'hidden';
                userIdField.name = 'user_id';
                userIdField.value = userIdInput.value;
                form.appendChild(userIdField);

                // Product input (combined name and price)
                const productField = document.createElement('input');
                productField.type = 'hidden';
                productField.name = 'product';
                productField.value = `${selectedProduct.name}|${selectedProduct.price.replace('Rp ', '').replace(/\./g, '')}`;
                form.appendChild(productField);

                // Payment Method input
                const paymentMethodField = document.createElement('input');
                paymentMethodField.type = 'hidden';
                paymentMethodField.name = 'payment_method';
                paymentMethodField.value = selectedPaymentMethod;
                form.appendChild(paymentMethodField);

                // Confirmation input
                const confirmField = document.createElement('input');
                confirmField.type = 'hidden';
                confirmField.name = 'Confirm';
                confirmField.value = 'true';
                form.appendChild(confirmField);

                // Submit form
                document.body.appendChild(form);
                form.submit();
            } catch (error) {
                console.error('Error during form submission:', error);
                alert('An error occurred while submitting the form.');
            }
        });

        // Update Modal Preview
        function updateModalPreview() {
            try {
                const modalUserId = document.getElementById('modal-user-id');
                const modalProduct = document.getElementById('modal-product');
                const modalPrice = document.getElementById('modal-price');
                const modalPaymentMethod = document.getElementById('modal-payment-method');

                // Update User ID
                modalUserId.textContent = userIdInput.value || '#12345';

                // Update Product
                if (selectedProduct) {
                    modalProduct.textContent = selectedProduct.name;
                    modalPrice.textContent = selectedProduct.price;
                }

                // Update Payment Method
                if (selectedPaymentMethod) {
                    modalPaymentMethod.textContent = selectedPaymentMethod;
                }
            } catch (error) {
                console.error('Error updating modal preview:', error);
                alert('An error occurred while updating the modal preview.');
            }
        }
    } catch (error) {
        console.error('Error initializing the page:', error);
        alert('An error occurred while initializing the page.');
    }
});
