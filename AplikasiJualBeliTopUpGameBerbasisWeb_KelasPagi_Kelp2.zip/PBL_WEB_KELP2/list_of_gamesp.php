<?php

// Nama File : list_of_gamesp.php
// Deskripsi : Kode ini merupakan kode yang menampilkan list of game yang ada di website kami di sisi penjual
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 08-desember-2024

try {
    session_start(); // Mulai sesi

    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['type_user'])) {
        // Pengguna belum login, arahkan ke halaman login
        header("Location: login.php");
        exit();
    }

    // Cek apakah tipe user yang login adalah 'penjual'
    // Jika bukan penjual, arahkan ke halaman dashboard pembeli
    if ($_SESSION['type_user'] !== 'penjual') {
        header("Location: dashboard.php"); // Dashboard pembeli
        exit();
    }
} catch (Exception $e) {
    // Menangani exception dan menampilkan pesan error
    echo "Terjadi kesalahan: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="btc.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600&display=swap" rel="stylesheet">

    <link href="styled.css" rel="stylesheet">
    <title>BTC Top Up Game Store</title>
</head>

<body>
    <!-- Header Section -->
    <button class="btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
        aria-controls="offcanvasMenu">
        ☰
    </button>
    <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasMenuLabel">
            <img src="btc.png" class="logo" alt="BTC Logo">
        </h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
  <ul class="nav flex-column">
    <li class="nav-item">
      <a href="dashboard_penjual.php" class="nav-link text-white">
        <i class="fas fa-home"></i> HOME
      </a>
    </li>
    <li class="nav-item">
      <a href="list_of_gamesp.php" class="nav-link text-white active">
        <i class="fas fa-gamepad"></i> LIST OF GAMES
      </a>
    </li>
    <li class="nav-item">
      <a href="profile_penjual.php" class="nav-link text-white">
        <i class="fas fa-user"></i> ACCOUNT
      </a>
    </li>
  </ul>
</div>

</div>

    <header class="header">
        <div class="header-left">
            <div class="header-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search Game" id="searchInput">
            </div>
        </div>
    </header>
    <!-- Search Popup -->
    <div class="search-overlay" id="searchOverlay"></div>
    <div class="search-popup" id="searchPopup">
        <div class="search-popup-header">
            <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <h3 id="searchTerm"></h3>
        </div>
        <div class="search-results" id="searchResults">
            <!-- Search results will be inserted here -->
        </div>
    </div>
<!-- Game List Section -->
<section class="game-list">
  <!-- Game Item 1 -->
  <div class="game-item">
    <a href="produk1_penjual.php">
      <img src="pubg.jpg" alt="PUBG">
      <div class="game-info">
        <h2 class="game-title">PUBG Mobile</h2> <!-- Teks di atas -->
        <p class="game-subtitle">Tencent Games</p> <!-- Teks di bawah -->
      </div>
    </a>
  </div>

  <!-- Game Item 2 -->
  <div class="game-item" data-description="PUBG - Game battle royale action">
    <a href="produk2_penjual.php">
      <img src="mobile_legends.jpg" alt="Mobile Legends">
      <div class="game-info">
        <h2 class="game-title">Mobile Legends</h2> <!-- Teks di atas -->
        <p class="game-subtitle">Moonton</p> <!-- Teks di bawah -->
      </div>
    </a>
  </div>

  <!-- Game Item 3 -->
  <div class="game-item">
    <a href="produk3_penjual.php">
      <img src="freefire.jpg" alt="Free Fire">
      <div class="game-info">
        <h2 class="game-title">Free Fire</h2> <!-- Teks di atas -->
        <p class="game-subtitle">Garena</p> <!-- Teks di bawah -->
      </div>
    </a>
  </div>
</section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="btc.png" alt="BTC Logo">
            </div>
            <div class="footer-text">
                <p>Nikmati kemudahan top-up diamond game favorit Anda menggunakan BTC Top Up Game Store! Kami
                    menghadirkan
                    solusi modern untuk para gamer yang ingin mengisi saldo diamond dan uc dengan cepat.</p>
            </div>
        </div>
        <p>© 2025 BTC Top Up Game Store. All Right Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    try {
        // Game database
        const games = [
            {
                id: 1,
                name: 'PUBG MOBILE',
                image: 'pubg.jpg',
                description: 'TENCENT GAMES',
                link: 'produk1_penjual.php'
            },
            {
                id: 2,
                name: 'MOBILE LEGEND',
                image: 'mobile_legends.jpg',
                description: 'MOONTON',
                link: 'produk2_penjual.php'
            },
            {
                id: 3,
                name: 'FREE FIRE',
                image: 'freefire.jpg',
                description: 'GARENA',
                link: 'produk3_penjual.php'
            }
        ];

        const searchInput = document.getElementById('searchInput');
        const searchPopup = document.getElementById('searchPopup');
        const searchOverlay = document.getElementById('searchOverlay');
        const searchTerm = document.getElementById('searchTerm');
        const searchResults = document.getElementById('searchResults');

        function createGameElement(game) {
            return `
            <a href="${game.link}" class="search-result-item">
              <img src="${game.image}" alt="${game.name}" class="game-preview-img">
              <div class="game-info">
                <h2 class="game-preview-title">${game.name}</h2>
                <p>${game.description}</p>
              </div>
            </a>
          `;
        }

        function filterGames(searchTerm) {
            return games.filter(game =>
                game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                game.description.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        function updateSearchResults(searchTerm) {
            const filteredGames = filterGames(searchTerm);

            if (filteredGames.length === 0) {
                searchResults.innerHTML = '<div class="no-results">No games found</div>';
            } else {
                searchResults.innerHTML = filteredGames.map(game => createGameElement(game)).join('');
            }
        }

        searchInput.addEventListener('input', function () {
            if (this.value.length > 0) {
                searchPopup.classList.add('active');
                searchOverlay.classList.add('active');
                searchTerm.textContent = this.value;
                updateSearchResults(this.value);
            } else {
                searchPopup.classList.remove('active');
                searchOverlay.classList.remove('active');
            }
        });

        searchOverlay.addEventListener('click', function () {
            searchPopup.classList.remove('active');
            searchOverlay.classList.remove('active');
            searchInput.value = '';
        });
    } catch (e) {
        console.error("Terjadi kesalahan:", e.message);
    }
</script>
</body>

</html>