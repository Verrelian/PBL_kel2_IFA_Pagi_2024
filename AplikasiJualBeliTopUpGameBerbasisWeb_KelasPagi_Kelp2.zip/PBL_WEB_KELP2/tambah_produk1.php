<?php

// Nama File : tambah_produk1.php
// Deskripsi : Kode ini merupakan kode yang mengatur fitur CRUD yaitu bagian Create/tambah produk pubg di sisi penjual
// Dibuat Oleh : Wahyudi - 3312401014
// Tanggal Pembuatan : 02-desember-2024

session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['type_user'])) {
    // Pengguna belum login, arahkan ke halaman login
    header("Location: login.php");
    exit();
}

// Cek apakah tipe user yang login adalah 'penjual'
// Jika bukan penjual, arahkan ke halaman dashboard pembeli
if ($_SESSION['type_user'] !== 'penjual') {
    header("Location: dashboard.php"); // Dashboard pembeli
    exit();
}

include 'koneksi.php';

// Pastikan koneksi berhasil
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data produk dari form
    $nama_produk = $_POST['nama_produk'];
    $harga_produk = $_POST['harga_produk'];
    $stock = $_POST['stok'];

    // Menangani upload gambar
    if (isset($_FILES['gambar_produk']) && $_FILES['gambar_produk']['error'] == 0) {
        $target_dir = "uploads/"; // Folder untuk menyimpan gambar
        $target_file = $target_dir . basename($_FILES["gambar_produk"]["name"]);

        // Validasi jenis file gambar
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        // Cek apakah file yang di-upload valid
        if (!in_array($file_type, $allowed_types)) {
            die("Jenis file tidak valid. Hanya JPG, JPEG, PNG, GIF yang diperbolehkan.");
        }

        // Pindahkan file ke folder uploads
        if (!move_uploaded_file($_FILES["gambar_produk"]["tmp_name"], $target_file)) {
            die("Terjadi kesalahan saat meng-upload gambar.");
        }

        $gambar_produk = $target_file; // Menyimpan path gambar
    } else {
        // Jika tidak ada gambar, pakai gambar default
        $gambar_produk = "uploads/default_image.jpg";
    }

    // Query untuk menyimpan produk ke database
    $query = "INSERT INTO pubg (nama_produk, harga_produk, stok, gambar)
              VALUES ('$nama_produk', '$harga_produk', '$stock', '$gambar_produk')";

    // Eksekusi query dan penanganan error
    try {
        $input = mysqli_query($koneksi, $query);

        if ($input) {
            echo "<script>
                alert('Data Berhasil Disimpan');
                window.location.href = 'produk1_penjual.php';
            </script>";
        } else {
            throw new Exception("Gagal Menyimpan Data: " . mysqli_error($koneksi));
        }
    } catch (Exception $e) {
        // Tangani error dan beri informasi kepada pengguna
        echo "<script>
            alert('Terjadi kesalahan: " . $e->getMessage() . "');
            window.location.href = 'produk1_penjual.php';
        </script>";
    }
} else {
    echo "Metode permintaan tidak valid.";
}

// Tutup koneksi
mysqli_close($koneksi);
?>
