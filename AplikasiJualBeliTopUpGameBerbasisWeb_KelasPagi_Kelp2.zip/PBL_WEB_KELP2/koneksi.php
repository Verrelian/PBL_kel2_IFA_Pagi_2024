<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "btc_store";

    //membuat koneksi
    $koneksi = new mysqli($servername,$username,$password,$dbname);

    //memeriksa koneksi benar atau salah
    if  ($koneksi->connect_error) {
        die ("Koneksi Gagal : " . $koneksi->connect_error);
    }
?>


